"""Command line: ``visionext URL add INPUT``, ``… remove ID``, ``… list``, ``… watch`` (default)."""
from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

from .client import connect
from .errors import VisioNextError
from .records import Source


def describe(source: Source) -> str:
    return f"{source.source_id}\t{source.kind}\t{source.status}\tevery {source.every_n_frames}\tframe {source.frame_index}\t{source.input}"


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="visionext", description="Manage a detection container's video sources and print the records it pushes")
    parser.add_argument("url", help="ws://host:port of a running container")
    parser.add_argument("-v", "--verbose", action="store_true", help="show connection and source events")
    commands = parser.add_subparsers(dest="command")
    watch = commands.add_parser("watch", help="print one line per frame with detections (default)")
    watch.add_argument("--all", action="store_true", help="also print frames with no detections")
    watch.add_argument("--save", metavar="DIR", help="save the JPEG of every frame with detections under DIR/<source_id>/<frame_index>.jpg")
    watch.add_argument("--once", action="store_true", help="do not reconnect when the container goes away")
    add = commands.add_parser("add", help="start reading a stream URL or a video file path (inside the container)")
    add.add_argument("input")
    add.add_argument("--id", dest="source_id", help="source_id to use in records (default: derived from the input)")
    add.add_argument("--every-n-frames", type=int, default=1, help="process every Nth frame of this source (default: 1)")
    remove = commands.add_parser("remove", help="stop reading a source")
    remove.add_argument("source_id")
    commands.add_parser("list", help="show the container's sources")

    argv = list(sys.argv[1:] if argv is None else argv)
    if argv and not argv[0].startswith("-") and not any(a in ("watch", "add", "remove", "list") for a in argv[1:2]):
        argv.insert(1, "watch")  # `visionext URL --all` means watch
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO if args.verbose else logging.WARNING, format="%(levelname)s %(message)s")

    try:
        with connect(args.url, reconnect=not getattr(args, "once", False), connect_timeout=None if args.command == "watch" else 30) as stream:
            if args.command == "add":
                print(describe(stream.add_source(args.input, source_id=args.source_id, every_n_frames=args.every_n_frames)))
            elif args.command == "remove":
                print(describe(stream.remove_source(args.source_id)))
            elif args.command == "list":
                for source in stream.list_sources():
                    print(describe(source))
            else:
                stream.on_source = lambda event, source: print(f"[source {event}] {describe(source)}", file=sys.stderr, flush=True)
                for record in stream:
                    if not record.events and not args.all:
                        continue
                    summary = ", ".join(f"{e.label} {e.confidence:.2f}" for e in record.events) or "-"
                    line = f"{record.timestamp:%H:%M:%S} {record.source_id} #{record.frame_index} {summary}"
                    if args.save and record.events and record.frame:
                        line += "  -> " + str(record.frame.save(Path(args.save) / record.source_id / f"{record.frame_index:012d}.jpg"))
                    print(line, flush=True)
    except KeyboardInterrupt:
        return 130
    except (VisioNextError, ConnectionError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
