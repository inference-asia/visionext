"""Typed views over the JSON records the containers push.

Every object keeps the original dict in ``.raw`` so nothing is lost if the
record schema grows a field the SDK does not know yet.
"""
from __future__ import annotations

import base64
import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .labels import label_for


@dataclass(frozen=True)
class Point:
    x: float
    y: float

    def __iter__(self):
        yield self.x
        yield self.y


@dataclass(frozen=True)
class BBox:
    """Axis-aligned box in pixel coordinates of the frame."""

    x1: float
    y1: float
    x2: float
    y2: float

    @property
    def width(self) -> float:
        return self.x2 - self.x1

    @property
    def height(self) -> float:
        return self.y2 - self.y1

    @property
    def area(self) -> float:
        return max(self.width, 0.0) * max(self.height, 0.0)

    @property
    def center(self) -> Point:
        return Point((self.x1 + self.x2) / 2, (self.y1 + self.y2) / 2)

    def xyxy(self) -> tuple[float, float, float, float]:
        return (self.x1, self.y1, self.x2, self.y2)

    def xywh(self) -> tuple[float, float, float, float]:
        return (self.x1, self.y1, self.width, self.height)

    def rounded(self) -> tuple[int, int, int, int]:
        """Integer ``(x1, y1, x2, y2)`` for drawing or cropping."""
        return (round(self.x1), round(self.y1), round(self.x2), round(self.y2))

    def contains(self, x: float, y: float) -> bool:
        return self.x1 <= x <= self.x2 and self.y1 <= y <= self.y2

    def __iter__(self):
        yield from self.xyxy()


@dataclass
class Event:
    """One detection in a frame.

    ``label`` is always something readable: the class name for objects
    (``"person"``), the identity for faces (``"alice"`` or ``"unknown"``).
    """

    name: str  # "object.detected", "face.detected", "face.recognized"
    confidence: float
    bbox: BBox
    label: str
    raw: dict[str, Any] = field(repr=False)
    # object.detected
    class_id: int | None = None
    # face.*
    identity: str | None = None
    similarity: float | None = None
    landmarks: list[Point] = field(default_factory=list)
    record: Record | None = field(default=None, repr=False, compare=False)

    @property
    def kind(self) -> str:
        """``"object"`` or ``"face"``."""
        return self.name.split(".", 1)[0]

    @property
    def is_object(self) -> bool:
        return self.kind == "object"

    @property
    def is_face(self) -> bool:
        return self.kind == "face"

    @property
    def recognized(self) -> bool:
        """True for a face matched against the gallery."""
        return self.name == "face.recognized"

    @classmethod
    def from_dict(cls, data: dict[str, Any], record: Record | None = None) -> Event:
        name = str(data.get("event_name", ""))
        box = data.get("bbox") or {}
        bbox = BBox(float(box.get("x1", 0)), float(box.get("y1", 0)), float(box.get("x2", 0)), float(box.get("y2", 0)))
        class_id = int(data["class_id"]) if data.get("class_id") is not None else None
        identity = data.get("identity")
        if name.startswith("face"):
            label = str(identity) if identity is not None else "unknown"
        else:
            label = label_for(class_id, str(data.get("label", "")))
        similarity = data.get("similarity")
        return cls(
            name=name,
            confidence=float(data.get("confidence", 0.0)),
            bbox=bbox,
            label=label,
            raw=data,
            class_id=class_id,
            identity=str(identity) if identity is not None else None,
            similarity=float(similarity) if similarity is not None else None,
            landmarks=[Point(float(x), float(y)) for x, y in data.get("landmarks") or []],
            record=record,
        )


@dataclass
class Frame:
    """The JPEG of the frame (present unless the deployment disabled frames)."""

    format: str
    quality: int
    base64: str = field(repr=False)
    _bytes: bytes | None = field(default=None, repr=False, compare=False)

    @property
    def bytes(self) -> bytes:
        """Decoded image file contents (a complete JPEG)."""
        if self._bytes is None:
            self._bytes = base64.b64decode(self.base64)
        return self._bytes

    def save(self, path: str | Path) -> Path:
        """Write the JPEG to ``path`` (parent directories are created)."""
        target = Path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(self.bytes)
        return target

    def to_pil(self):
        """Decode with Pillow (``pip install visionext[pillow]``)."""
        try:
            from io import BytesIO

            from PIL import Image
        except ImportError as exc:  # pragma: no cover
            raise ImportError("Frame.to_pil() needs Pillow: pip install Pillow") from exc
        return Image.open(BytesIO(self.bytes)).convert("RGB")

    def to_numpy(self):
        """Decode with OpenCV to a BGR ``numpy.ndarray`` (``pip install visionext[numpy]``)."""
        try:
            import cv2
            import numpy as np
        except ImportError as exc:  # pragma: no cover
            raise ImportError("Frame.to_numpy() needs numpy and OpenCV: pip install numpy opencv-python-headless") from exc
        return cv2.imdecode(np.frombuffer(self.bytes, dtype=np.uint8), cv2.IMREAD_COLOR)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Frame:
        return cls(format=str(data.get("format", "jpeg")), quality=int(data.get("quality", 0)), base64=str(data.get("base64", "")))


@dataclass
class Record:
    """One sampled frame: metadata, its detections, and optionally the image."""

    source_id: str
    timestamp: datetime
    frame_index: int
    frame_width: int
    frame_height: int
    events: list[Event]
    frame: Frame | None
    schema_version: str
    raw: dict[str, Any] = field(repr=False)

    @property
    def size(self) -> tuple[int, int]:
        """``(width, height)`` in pixels."""
        return (self.frame_width, self.frame_height)

    @property
    def objects(self) -> list[Event]:
        return [e for e in self.events if e.is_object]

    @property
    def faces(self) -> list[Event]:
        return [e for e in self.events if e.is_face]

    @property
    def has_events(self) -> bool:
        return bool(self.events)

    def __bool__(self) -> bool:  # a record is always a record, even with no detections
        return True

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Record:
        record = cls(
            source_id=str(data.get("source_id", "")),
            timestamp=_parse_timestamp(data.get("timestamp")),
            frame_index=int(data.get("frame_index", 0)),
            frame_width=int(data.get("frame_width", 0)),
            frame_height=int(data.get("frame_height", 0)),
            events=[],
            frame=Frame.from_dict(data["frame"]) if data.get("frame") else None,
            schema_version=str(data.get("schema_version", "")),
            raw=data,
        )
        record.events = [Event.from_dict(e, record) for e in data.get("events") or []]
        return record

    @classmethod
    def from_json(cls, text: str | bytes) -> Record:
        return cls.from_dict(json.loads(text))


@dataclass
class Source:
    """A video input the container is reading, as reported by the container."""

    source_id: str
    input: str  # path or URL with any credentials removed
    kind: str  # "file" or "stream"
    every_n_frames: int
    status: str  # "open", "reconnecting", "ended", "removed"
    frame_index: int
    raw: dict[str, Any] = field(repr=False, default_factory=dict)

    @property
    def is_file(self) -> bool:
        return self.kind == "file"

    @property
    def is_stream(self) -> bool:
        return self.kind == "stream"

    @property
    def is_open(self) -> bool:
        return self.status == "open"

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Source:
        return cls(
            source_id=str(data.get("source_id", "")),
            input=str(data.get("input", "")),
            kind=str(data.get("kind", "")),
            every_n_frames=int(data.get("every_n_frames", 1)),
            status=str(data.get("status", "")),
            frame_index=int(data.get("frame_index", 0)),
            raw=data,
        )


def _parse_timestamp(value: Any) -> datetime:
    if not value:
        return datetime.fromtimestamp(0, tz=timezone.utc)
    text = str(value)
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"  # fromisoformat accepts "Z" only from Python 3.11
    parsed = datetime.fromisoformat(text)
    return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)
