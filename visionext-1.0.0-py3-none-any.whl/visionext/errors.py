class VisioNextError(Exception):
    """Base class for errors raised by this package."""


class RequestError(VisioNextError):
    """The container rejected a request (add/remove/list); ``str(exc)`` is its reason."""

    def __init__(self, action: str, message: str):
        super().__init__(message)
        self.action = action


class RequestTimeout(VisioNextError, TimeoutError):
    """No reply arrived in time (the container may be busy opening a stream)."""


class StreamClosed(VisioNextError):
    """The stream was closed (or dropped and ``reconnect=False``) while a request was pending."""
