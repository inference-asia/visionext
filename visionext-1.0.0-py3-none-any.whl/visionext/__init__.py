"""VisioNext SDK: Python client for the VisioNext vision AI engine containers.

    import visionext

    stream = visionext.connect("ws://localhost:8765")
    stream.add_source("rtsp://user:pass@camera/live", every_n_frames=25)
    for record in stream:
        for event in record.events:
            print(record.source_id, record.frame_index, event.label, round(event.confidence, 2), event.bbox.rounded())
"""
from .client import AsyncStream, Stream, aconnect, connect
from .errors import VisioNextError, RequestError, RequestTimeout, StreamClosed
from .labels import COCO_LABELS, label_for
from .records import BBox, Event, Frame, Point, Record, Source

__version__ = "1.0.0"
__all__ = [
    "connect", "aconnect", "Stream", "AsyncStream",
    "Record", "Event", "Frame", "BBox", "Point", "Source",
    "VisioNextError", "RequestError", "RequestTimeout", "StreamClosed",
    "COCO_LABELS", "label_for", "__version__",
]
