"""Connect to a container's WebSocket endpoint, manage its video sources, and iterate over its records.

    stream = connect("ws://localhost:8765")
    stream.add_source("rtsp://cam/live", every_n_frames=25)
    for record in stream:
        ...

The stream connects lazily, waits for the container to come up, reconnects
when it restarts (re-adding the sources added through this stream), and raises
:class:`RequestError` when the container rejects a request.
"""
from __future__ import annotations

import asyncio
import json
import logging
import threading
import time
from collections import deque
from typing import Any, AsyncIterator, Callable, Iterator

from websockets.exceptions import ConnectionClosed, InvalidHandshake, InvalidURI

from .errors import RequestError, RequestTimeout, StreamClosed
from .records import Event, Record, Source

LOG = logging.getLogger("visionext")

# Failures while opening that mean "not up yet": refused/unreachable, a proxy
# (docker -p) that accepts TCP and then resets before the container listens,
# a bad HTTP reply, or a handshake that times out.
_RETRYABLE = (OSError, ConnectionClosed, InvalidHandshake, TimeoutError, asyncio.TimeoutError)

SourceCallback = Callable[[str, Source], None]


def normalize_url(url: str) -> str:
    """Accept ``host:port``, ``ws://host:port`` or ``wss://…``."""
    if "://" not in url:
        url = "ws://" + url
    if url.startswith(("http://", "https://")):
        url = "ws" + url[4:]
    if not url.startswith(("ws://", "wss://")):
        raise InvalidURI(url, "expected a ws:// or wss:// URL")
    return url


class _Base:
    def __init__(self, url: str, *, reconnect: bool = True, retry_every: float = 2.0, connect_timeout: float | None = None, request_timeout: float = 30.0, max_size: int | None = None, on_source: SourceCallback | None = None):
        self.url = normalize_url(url)
        self.reconnect = reconnect
        self.retry_every = retry_every
        self.connect_timeout = connect_timeout
        self.request_timeout = request_timeout
        self.max_size = max_size  # None: no limit, records with frames can exceed 1 MB
        self.on_source = on_source  # called as on_source(event, source) for added/removed/opened/lost/ended
        self.sources: dict[str, Source] = {}  # last known state, keyed by source_id
        self.close_code: int | None = None
        self.close_reason: str | None = None
        self._closed = False  # the user called close()
        self._finished = False  # iteration is over
        self._ws: Any = None
        self._buffered: deque[Record] = deque()  # records received while waiting for a reply
        self._pending: dict[int, Any] = {}  # request id -> holder for its reply
        self._next_id = 0
        self._added: dict[str, tuple[str, int]] = {}  # sources added through this stream, re-added after a reconnect

    @property
    def connected(self) -> bool:
        return self._ws is not None

    def _dispatch(self, message: str | bytes) -> Record | None:
        """Route one incoming message; returns it if it is a record."""
        data = json.loads(message)
        kind = data.get("type")
        if kind is None:
            return Record.from_dict(data)
        if kind == "reply":
            holder = self._pending.pop(data.get("id"), None)
            if holder is not None:
                holder.set(data)
        elif kind == "source":
            source = Source.from_dict(data.get("source") or {})
            event = str(data.get("event"))
            if event in ("removed", "ended"):
                self.sources.pop(source.source_id, None)
                self._added.pop(source.source_id, None)
            else:
                self.sources[source.source_id] = source
            if event == "lost":
                LOG.warning("%s: source %s lost; the container is reconnecting", self.url, source.source_id)
            elif event == "ended":
                LOG.info("%s: source %s ended", self.url, source.source_id)
            if self.on_source is not None:
                self.on_source(event, source)
        return None

    def _on_closed(self, exc: ConnectionClosed) -> None:
        """Bookkeeping after the connection dropped; decides whether iteration continues."""
        frame = exc.rcvd or exc.sent
        self.close_code = frame.code if frame else 1006
        self.close_reason = frame.reason if frame else ""
        self._ws = None
        if self._closed:
            self._finished = True
        elif not self.reconnect:
            LOG.info("%s: connection closed (%s %s)", self.url, self.close_code, self.close_reason)
            self._finished = True
        else:
            LOG.warning("%s: connection lost (%s %s); reconnecting", self.url, self.close_code, self.close_reason)
        for holder in self._pending.values():
            holder.fail(StreamClosed(f"connection to {self.url} closed while waiting for a reply ({self.close_code} {self.close_reason})"))
        self._pending.clear()

    def _retry_or_raise(self, started: float, exc: Exception) -> None:
        if self.connect_timeout is not None and time.monotonic() - started >= self.connect_timeout:
            raise ConnectionError(f"could not connect to {self.url} within {self.connect_timeout:g}s: {exc}") from None
        LOG.debug("%s: not reachable (%s); retrying in %gs", self.url, exc, self.retry_every)

    def _new_request(self, action: str, **fields: Any) -> dict[str, Any]:
        self._next_id += 1
        return {"id": self._next_id, "action": action, **fields}

    def _result(self, request: dict[str, Any], reply: dict[str, Any]) -> Any:
        if not reply.get("ok"):
            raise RequestError(request["action"], str(reply.get("error", "request failed")))
        if "sources" in reply:
            sources = [Source.from_dict(s) for s in reply["sources"]]
            self.sources = {s.source_id: s for s in sources}
            return sources
        source = Source.from_dict(reply.get("source") or {})
        if request["action"] == "add":
            self.sources[source.source_id] = source
            self._added[source.source_id] = (request["input"], request["every_n_frames"])
        else:
            self.sources.pop(source.source_id, None)
            self._added.pop(source.source_id, None)
        return source


class _Holder:
    """Reply slot for a pending request (threads)."""

    def __init__(self) -> None:
        self.event = threading.Event()
        self.reply: dict[str, Any] | None = None
        self.error: Exception | None = None

    def set(self, reply: dict[str, Any]) -> None:
        self.reply = reply
        self.event.set()

    def fail(self, error: Exception) -> None:
        self.error = error
        self.event.set()


class Stream(_Base):
    """Blocking record iterator with source management. Use :func:`connect` to create one."""

    def __init__(self, *args: Any, **kwargs: Any):
        super().__init__(*args, **kwargs)
        self._recv_lock = threading.Lock()  # whoever holds it reads from the socket and dispatches
        self._open_lock = threading.Lock()

    # --- iteration ---------------------------------------------------------

    def __enter__(self) -> Stream:
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()

    def __iter__(self) -> Iterator[Record]:
        return self

    def __next__(self) -> Record:
        while True:
            if self._buffered:
                return self._buffered.popleft()
            if self._finished:
                raise StopIteration
            if self._ws is None:
                self._open()
                continue
            with self._recv_lock:
                if self._buffered or self._ws is None:
                    continue
                try:
                    message = self._ws.recv()
                except ConnectionClosed as exc:
                    self._on_closed(exc)
                    continue
                record = self._dispatch(message)
            if record is not None:
                return record

    def events(self) -> Iterator[Event]:
        """Iterate over detections instead of frames; each event knows its ``record``."""
        for record in self:
            yield from record.events

    def detections(self) -> Iterator[Record]:
        """Only the records that contain at least one event."""
        return (record for record in self if record.events)

    def close(self) -> None:
        """Disconnect; a running iteration stops."""
        self._closed = True
        self._finished = True
        ws, self._ws = self._ws, None
        if ws is not None:
            ws.close()
        for holder in self._pending.values():
            holder.fail(StreamClosed("stream closed"))
        self._pending.clear()

    # --- sources -------------------------------------------------------------

    def add_source(self, input: str, *, source_id: str | None = None, every_n_frames: int = 1) -> Source:
        """Ask the container to start reading ``input`` (a stream URL or a file path inside the container).

        ``every_n_frames`` samples every Nth frame of this source. ``source_id``
        defaults to the input's last path segment and is what records carry.
        Raises :class:`RequestError` if the container refuses (unreadable file,
        id already used by another input, …). A stream that is currently
        unreachable is accepted and retried by the container. The source is
        re-added automatically if this stream has to reconnect.
        """
        request = self._new_request("add", input=input, every_n_frames=every_n_frames)
        if source_id is not None:
            request["source_id"] = source_id
        return self._request(request)

    def remove_source(self, source_id: str) -> Source:
        """Stop reading a source. Raises :class:`RequestError` if it does not exist."""
        return self._request(self._new_request("remove", source_id=source_id))

    def list_sources(self) -> list[Source]:
        """The container's current sources (also refreshes ``stream.sources``)."""
        return self._request(self._new_request("list"))

    def _request(self, request: dict[str, Any]) -> Any:
        if self._closed:
            raise StreamClosed("stream closed")
        if self._ws is None:
            self._open()
            if self._ws is None:
                raise StreamClosed("stream closed")
        holder = _Holder()
        self._pending[request["id"]] = holder
        try:
            self._ws.send(json.dumps(request))
        except ConnectionClosed as exc:
            self._on_closed(exc)
        deadline = time.monotonic() + self.request_timeout
        while not holder.event.is_set():
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                self._pending.pop(request["id"], None)
                raise RequestTimeout(f"no reply to {request['action']} within {self.request_timeout:g}s")
            if self._recv_lock.acquire(timeout=min(remaining, 0.1)):
                # Nobody is iterating right now: read (and buffer records) until the reply is here.
                try:
                    if holder.event.is_set():
                        break
                    if self._ws is None:
                        break
                    try:
                        message = self._ws.recv(timeout=min(remaining, 1.0))
                    except TimeoutError:
                        continue
                    except ConnectionClosed as exc:
                        self._on_closed(exc)
                        continue
                    record = self._dispatch(message)
                    if record is not None:
                        self._buffered.append(record)
                finally:
                    self._recv_lock.release()
            # else: the iterating thread is reading and will fill the holder
        if holder.error is not None:
            raise holder.error
        assert holder.reply is not None
        return self._result(request, holder.reply)

    def _open(self) -> None:
        from websockets.sync.client import connect as ws_connect

        with self._open_lock:
            if self._ws is not None or self._closed:
                return
            started = time.monotonic()
            while not self._closed:
                try:
                    ws = ws_connect(self.url, max_size=self.max_size, open_timeout=10)
                except _RETRYABLE as exc:
                    self._retry_or_raise(started, exc)
                    time.sleep(self.retry_every)
                    continue
                LOG.info("%s: connected", self.url)
                self._ws = ws
                break
            else:
                self._finished = True
                return
        for source_id, (input, every) in list(self._added.items()):
            try:
                self._request(self._new_request("add", input=input, every_n_frames=every, source_id=source_id))
                LOG.info("%s: re-added source %s", self.url, source_id)
            except (RequestError, RequestTimeout, StreamClosed) as exc:
                LOG.error("%s: could not re-add source %s: %s", self.url, source_id, exc)


class _AsyncHolder:
    def __init__(self) -> None:
        self.future: asyncio.Future = asyncio.get_running_loop().create_future()

    def set(self, reply: dict[str, Any]) -> None:
        if not self.future.done():
            self.future.set_result(reply)

    def fail(self, error: Exception) -> None:
        if not self.future.done():
            self.future.set_exception(error)


class AsyncStream(_Base):
    """asyncio counterpart of :class:`Stream`. Use :func:`aconnect` to create one."""

    def __init__(self, *args: Any, **kwargs: Any):
        super().__init__(*args, **kwargs)
        self._recv_lock = asyncio.Lock()
        self._open_lock = asyncio.Lock()

    async def __aenter__(self) -> AsyncStream:
        return self

    async def __aexit__(self, *_: Any) -> None:
        await self.aclose()

    def __aiter__(self) -> AsyncIterator[Record]:
        return self

    async def __anext__(self) -> Record:
        while True:
            if self._buffered:
                return self._buffered.popleft()
            if self._finished:
                raise StopAsyncIteration
            if self._ws is None:
                await self._open()
                continue
            async with self._recv_lock:
                if self._buffered or self._ws is None:
                    continue
                try:
                    message = await self._ws.recv()
                except ConnectionClosed as exc:
                    self._on_closed(exc)
                    continue
                record = self._dispatch(message)
            if record is not None:
                return record

    async def events(self) -> AsyncIterator[Event]:
        async for record in self:
            for event in record.events:
                yield event

    async def detections(self) -> AsyncIterator[Record]:
        async for record in self:
            if record.events:
                yield record

    async def aclose(self) -> None:
        """Disconnect; a running iteration stops."""
        self._closed = True
        self._finished = True
        ws, self._ws = self._ws, None
        if ws is not None:
            await ws.close()
        for holder in self._pending.values():
            holder.fail(StreamClosed("stream closed"))
        self._pending.clear()

    def close(self) -> None:
        """Non-async variant of :meth:`aclose`, usable from an ``on_source`` callback."""
        self._closed = True
        self._finished = True
        ws, self._ws = self._ws, None
        if ws is not None:
            asyncio.get_running_loop().create_task(ws.close())
        for holder in self._pending.values():
            holder.fail(StreamClosed("stream closed"))
        self._pending.clear()

    async def add_source(self, input: str, *, source_id: str | None = None, every_n_frames: int = 1) -> Source:
        request = self._new_request("add", input=input, every_n_frames=every_n_frames)
        if source_id is not None:
            request["source_id"] = source_id
        return await self._request(request)

    async def remove_source(self, source_id: str) -> Source:
        return await self._request(self._new_request("remove", source_id=source_id))

    async def list_sources(self) -> list[Source]:
        return await self._request(self._new_request("list"))

    async def _request(self, request: dict[str, Any]) -> Any:
        if self._closed:
            raise StreamClosed("stream closed")
        if self._ws is None:
            await self._open()
            if self._ws is None:
                raise StreamClosed("stream closed")
        holder = _AsyncHolder()
        self._pending[request["id"]] = holder
        try:
            await self._ws.send(json.dumps(request))
        except ConnectionClosed as exc:
            self._on_closed(exc)
        deadline = time.monotonic() + self.request_timeout
        while not holder.future.done():
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                self._pending.pop(request["id"], None)
                raise RequestTimeout(f"no reply to {request['action']} within {self.request_timeout:g}s")
            if self._recv_lock.locked():
                # An iteration is reading and will fill the future.
                try:
                    await asyncio.wait_for(asyncio.shield(holder.future), remaining)
                except asyncio.TimeoutError:
                    continue
                break
            async with self._recv_lock:
                if holder.future.done() or self._ws is None:
                    continue
                try:
                    message = await asyncio.wait_for(self._ws.recv(), min(remaining, 1.0))
                except asyncio.TimeoutError:
                    continue
                except ConnectionClosed as exc:
                    self._on_closed(exc)
                    continue
                record = self._dispatch(message)
                if record is not None:
                    self._buffered.append(record)
        return self._result(request, holder.future.result())

    async def _open(self) -> None:
        from websockets.asyncio.client import connect as ws_connect

        async with self._open_lock:
            if self._ws is not None or self._closed:
                return
            started = time.monotonic()
            while not self._closed:
                try:
                    ws = await ws_connect(self.url, max_size=self.max_size, open_timeout=10)
                except _RETRYABLE as exc:
                    self._retry_or_raise(started, exc)
                    await asyncio.sleep(self.retry_every)
                    continue
                LOG.info("%s: connected", self.url)
                self._ws = ws
                break
            else:
                self._finished = True
                return
        for source_id, (input, every) in list(self._added.items()):
            try:
                await self._request(self._new_request("add", input=input, every_n_frames=every, source_id=source_id))
                LOG.info("%s: re-added source %s", self.url, source_id)
            except (RequestError, RequestTimeout, StreamClosed) as exc:
                LOG.error("%s: could not re-add source %s: %s", self.url, source_id, exc)


def connect(url: str, *, reconnect: bool = True, retry_every: float = 2.0, connect_timeout: float | None = None, request_timeout: float = 30.0, max_size: int | None = None, on_source: SourceCallback | None = None) -> Stream:
    """Open a record stream from a container.

    Args:
        url: ``ws://host:port`` (``host:port`` also works).
        reconnect: keep the stream alive across container restarts and network
            drops, re-adding the sources added through it.
        retry_every: seconds between connection attempts while the container
            is unreachable (it opens its port only once the model is loaded).
        connect_timeout: give up (``ConnectionError``) if no connection could
            be made within this many seconds; ``None`` waits forever.
        request_timeout: seconds to wait for the container to answer
            ``add_source`` / ``remove_source`` / ``list_sources``
            (:class:`RequestTimeout`). Opening an unreachable stream can take
            the container up to ten seconds.
        max_size: maximum message size in bytes; ``None`` (default) accepts
            any size, which records with frames need.
        on_source: ``callback(event, source)`` for source notifications:
            ``added``, ``removed``, ``opened``, ``lost``, ``ended``.

    Nothing is sent or received until you add a source or start iterating.
    """
    return Stream(url, reconnect=reconnect, retry_every=retry_every, connect_timeout=connect_timeout, request_timeout=request_timeout, max_size=max_size, on_source=on_source)


def aconnect(url: str, *, reconnect: bool = True, retry_every: float = 2.0, connect_timeout: float | None = None, request_timeout: float = 30.0, max_size: int | None = None, on_source: SourceCallback | None = None) -> AsyncStream:
    """asyncio version of :func:`connect`: ``await stream.add_source(...)``, ``async for record in stream``."""
    return AsyncStream(url, reconnect=reconnect, retry_every=retry_every, connect_timeout=connect_timeout, request_timeout=request_timeout, max_size=max_size, on_source=on_source)
